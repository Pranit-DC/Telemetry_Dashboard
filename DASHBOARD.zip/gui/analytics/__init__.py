from .window import AnalyticsWindow
